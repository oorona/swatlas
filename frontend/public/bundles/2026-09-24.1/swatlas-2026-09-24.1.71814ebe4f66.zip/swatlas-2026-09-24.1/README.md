# swatlas bundle 2026-09-24.1

Star Wars semantic atlas: 15 character descriptions from the article
"Mapping the Star Wars Universe", embedded with sentence-transformers/all-MiniLM-L6-v2
at revision 1110a243fdf4706b3f48f1d95db1a4f5529b4d41 (apache-2.0).

## Files
- characters.csv: descriptions (authored + relationships-removed variant) and draft editorial fields.
- embeddings_<mode>.csv: L2-normalized 384-d vectors, one row per character id.
- similarity_<mode>.csv: original-space cosine matrix (rows/columns in id order).
- projections_<mode>.json: PCA and UMAP (seeds 7/21/42) coordinates with full parameters.
- claims.json: article claims checked against the scores.
- manifest.json: provenance, hashes, package versions, execution settings.

## Modes
- authored: input_hash 80fc55a1b1df00042ced75af409e22dfba02a5ded208363669a88be3d75dd3e5
- relationships_removed: input_hash d592f078e6f82e56eac3c95c2c7bdd4b31b8932aa5b848c2046d00ed61c40434

## Notes
- Cosine scores are computed on the original normalized vectors, never on projected coordinates.
- Editorial fields are drafts, not canon, and not embedding axes.
- CSV cells that begin with = + - @ are prefixed with an apostrophe to neutralize spreadsheet formulas.

## Limitations
- Fifteen hand-written descriptions from one blog article; results describe these texts, not the characters or the franchise.
- One small general-purpose embedding model (all-MiniLM-L6-v2). Other models will rank neighbors differently.
- Allegiance, role, era, and Force-status fields are draft editorial classifications, not canon and not embedding axes.
- The relationship-removed variant changes several phrases at once; a neighbor change cannot be attributed to a single factor.
- 2D projections distort distances. Rankings and scores always use the original 384-dimensional vectors.
- Floating-point results are reproducible within the pinned environment on CPU; identical bits across hardware are not promised.

Reproduce: ./scripts/build_bundle.sh --version 2026-09-24.1
