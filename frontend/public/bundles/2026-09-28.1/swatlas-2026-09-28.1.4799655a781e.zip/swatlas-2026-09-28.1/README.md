# swatlas bundle 2026-09-28.1

Star Wars semantic atlas: 15 character descriptions from the article
"Mapping the Star Wars Universe", embedded with intfloat/e5-large-v2
at revision f169b11e22de13617baa190a028a32f3493550b6 (mit).

## Files
- characters.csv: descriptions (authored + relationships-removed variant) and draft editorial fields.
- embeddings_<mode>.csv: L2-normalized 1024-d vectors, one row per character id.
- similarity_<mode>.csv: original-space cosine matrix (rows/columns in id order).
- projections_<mode>.json: PCA and UMAP (seeds 7/21/42) coordinates with full parameters.
- claims.json: article claims checked against the scores.
- manifest.json: provenance, hashes, package versions, execution settings.

## Modes
- authored: input_hash 8ff005673dad24aa49d3e8ca10611ec397488495c114f8b00fff592c3716b964
- relationships_removed: input_hash f0449cfbfd44addb5a8722f142a6da833f9a0d1fac03124ff8b2ff02ba4140dc

## Notes
- Cosine scores are computed on the original normalized vectors, never on projected coordinates.
- Editorial fields are drafts, not canon, and not embedding axes.
- CSV cells that begin with = + - @ are prefixed with an apostrophe to neutralize spreadsheet formulas.

## Limitations
- Fifteen hand-written descriptions from one blog article; results describe these texts, not the characters or the franchise.
- One general-purpose embedding model (e5-large-v2). Other models will rank neighbors differently.
- Allegiance, role, era, and Force-status fields are draft editorial classifications, not canon and not embedding axes.
- The relationship-removed variant changes several phrases at once; a neighbor change cannot be attributed to a single factor.
- 2D projections distort distances. Rankings and scores always use the original 1024-dimensional vectors.
- Floating-point results are reproducible within the pinned environment on CPU; identical bits across hardware are not promised.

Reproduce: ./scripts/build_bundle.sh --version 2026-09-28.1
